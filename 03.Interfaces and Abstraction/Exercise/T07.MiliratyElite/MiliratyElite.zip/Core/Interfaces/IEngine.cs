﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiliratyElite.Core.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
