﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiliratyElite.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}
