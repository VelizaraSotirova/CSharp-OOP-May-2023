﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiliratyElite.Models.Interfaces
{
    public interface IRepair
    {
        string Name { get; }
        int HoursWorked { get; }
    }
}
